/** Automatically generated file. DO NOT MODIFY */
package com.taseen.apps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}